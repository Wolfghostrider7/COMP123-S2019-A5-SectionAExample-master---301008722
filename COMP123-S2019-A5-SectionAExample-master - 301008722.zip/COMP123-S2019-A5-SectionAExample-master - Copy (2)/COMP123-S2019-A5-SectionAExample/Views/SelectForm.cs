﻿using COMP123_S2019_A5_SectionAExample.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Dollar Computers
 * Yan Ho Chan - 301008722
 * Created on: 8/15/2019
 * This is the Select Form
 */
namespace COMP123_S2019_A5_SectionAExample.Views
{

    public partial class SelectForm : Form
    {
       // private ProductInfoForm infoForm;
        public SelectForm()
        {
            InitializeComponent();
        }

      
        private void SelectForm_Load(object sender, EventArgs e)
        {

           // infoForm = new ProductInfoForm();
            // TODO: This line of code loads data into the 'dollarComputersDataSet.Products' table. You can move, or remove it, as needed.
            this.productsTableAdapter.Fill(this.dollarComputersDataSet.Products);
            if (!HasLoadedDataSource())
            {
                MessageBox.Show("DataSource Not Loaded", "ERROR", 
                    MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //cancel button exits application
        private void CancelButton_Click(object sender, EventArgs e)
        {
            Program.startForm.Show();
            this.Hide();
        }

        private void ProductDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            SelectLabel.Text = ProductDataGridViewSelectedItem();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Label1_Click_1(object sender, EventArgs e)
        {

        }
        // to the next form
        private void Next_Button(object sender, EventArgs e)
        {
            //Program.productInfoForm.Show();
//ProductDataGridView.Text = prodIDText.ProductName.ToString();
            this.Hide();
            ProductInfoForm myForm = new ProductInfoForm();

            myForm.prodIDText.Text = ProductDataGridView.CurrentRow.Cells[0].Value.ToString();
            myForm.textBox2.Text = ProductDataGridView.CurrentRow.Cells[1].Value.ToString();
            myForm.textBox3.Text = ProductDataGridView.CurrentRow.Cells[2].Value.ToString();
            myForm.textBox4.Text = ProductDataGridView.CurrentRow.Cells[3].Value.ToString();
            myForm.textBox5.Text = ProductDataGridView.CurrentRow.Cells[4].Value.ToString();
            myForm.textBox6.Text = ProductDataGridView.CurrentRow.Cells[5].Value.ToString();
            myForm.textBox7.Text = ProductDataGridView.CurrentRow.Cells[6].Value.ToString();
            myForm.textBox8.Text = ProductDataGridView.CurrentRow.Cells[7].Value.ToString();
            myForm.textBox9.Text = ProductDataGridView.CurrentRow.Cells[8].Value.ToString();
            myForm.textBox10.Text = ProductDataGridView.CurrentRow.Cells[9].Value.ToString();

            myForm.ShowDialog();

            /* Order form*/

           /*OrderForm myForm1 = new OrderForm();

            myForm1.prodIDText.Text = ProductDataGridView.CurrentRow.Cells[0].Value.ToString();
            myForm1.textBox2.Text = ProductDataGridView.CurrentRow.Cells[1].Value.ToString();
            myForm1.textBox3.Text = ProductDataGridView.CurrentRow.Cells[2].Value.ToString();
            myForm1.textBox4.Text = ProductDataGridView.CurrentRow.Cells[3].Value.ToString();
            myForm1.textBox5.Text = ProductDataGridView.CurrentRow.Cells[4].Value.ToString();
            myForm1.textBox6.Text = ProductDataGridView.CurrentRow.Cells[5].Value.ToString();
            myForm1.textBox7.Text = ProductDataGridView.CurrentRow.Cells[6].Value.ToString();
            myForm1.textBox8.Text = ProductDataGridView.CurrentRow.Cells[7].Value.ToString();
            myForm1.textBox9.Text = ProductDataGridView.CurrentRow.Cells[8].Value.ToString();
            myForm1.textBox10.Text = ProductDataGridView.CurrentRow.Cells[9].Value.ToString();

            myForm.ShowDialog();*/
        }

        private void ProductDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            }
        }
    }
