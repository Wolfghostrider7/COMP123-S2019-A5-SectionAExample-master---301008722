﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Dollar Computers
 * Yan Ho Chan - 301008722
 * Created on: 8/15/2019
 * This is the Splash Form
 */
namespace COMP123_S2019_A5_SectionAExample.Views
{
    public partial class SplashForm : Form
    {
        public SplashForm()
        {
            InitializeComponent();
        }
        //Timer for Splash Form transition
        private void SplashForm_Load(object sender, EventArgs e)
        {
            SplashTimer.Enabled = true;
        }

        private void SplashTimer_Tick(object sender, EventArgs e)
        {
            SplashTimer.Enabled = false;

            Program.startForm.Show();
            this.Hide();
        }
    }
    }
