﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
/*
 * Dollar Computers
 * Yan Ho Chan - 301008722
 * Created on: 8/15/2019
 * This is the Order Form
 */
namespace COMP123_S2019_A5_SectionAExample.Views
{
    public partial class OrderForm : Form
    {
        public OrderForm()
        {
            InitializeComponent();
        }

        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProductPrintForm.PrintAction = PrintAction.PrintToPreview;
            ProductPrintForm.Print();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Next_Button(object sender, EventArgs e)
        {
            Program.endForm.Show();
            this.Hide();
        }

        private void About_Button(object sender, EventArgs e)
        {
            Program.aboutForm.Show();
            this.Hide();
        }
    }
}
