﻿namespace Microsoft.VisualBasic
{
    internal class PowerPacks
    {
    }
}